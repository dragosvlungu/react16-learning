import * as actionTypes from '../actions/actionTypes';

import { updateObject } from '../../shared/utility';

const initialState = {
    ingredients: null,
    totalPrice: 4,
    error: false,
    building: false
};

const INGREDIENT_PRICES = {
    salad: 0.5,
    cheese: 0.4,
    meat: 1.3,
    bacon: 0.7
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.ADD_INGREDIENT :
            return addIngredients(action, state);
        case actionTypes.REMOVE_INGREDIENT: 
            return removeIngredient(action, state);
        case actionTypes.SET_INGREDIENTS:
            return setIngredients(action, state);
        case actionTypes.FETCH_INGREDIENT_FAILED:
            return updateObject(state, {error: true});
        default:
            return state;
    }
};

export default reducer;

const removeIngredient = (action, state) => {
    const updateIng = { [action.ingredientName]: state.ingredients[action.ingredientName] - 1 };
    const updatedIngr = updateObject(state.ingredients, updateIng);
    const updateSt = {
        ingredients: updatedIngr,
        totalPrice: state.totalPrice + INGREDIENT_PRICES[action.ingredientName],
        building: true
    };
    return updateObject(state, updateSt);
}

const  addIngredients = (action, state) => {
    const updateIngredient = { [action.ingredientName]: state.ingredients[action.ingredientName] + 1 };
    const updatedIngredients = updateObject(state.ingredients, updateIngredient);
    const updateState = {
        ingredients: updatedIngredients,
        totalPrice: state.totalPrice + INGREDIENT_PRICES[action.ingredientName],
        building: true
    };
    return updateObject(state, updateState);
}
const setIngredients = (action, state) => {
    const updatedInitialIngs = {
        salad: action.ingredients.salad,
        bacon: action.ingredients.bacon,
        cheese: action.ingredients.cheese,
        meat: action.ingredients.meat,
    };
    const stateIncrement = {
        ingredients: updatedInitialIngs,
        totalPrice: 4,
        error: false,
        building: false
    };
    return updateObject(state, stateIncrement);
}

