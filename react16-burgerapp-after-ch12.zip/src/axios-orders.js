import axios from 'axios';

const instance = axios.create({
    baseURL: 'https://react16-burger-cd28e.firebaseio.com/',
});

export default instance;